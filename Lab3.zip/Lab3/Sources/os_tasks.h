/*
 * os_tasks.h
 *
 *  Created on: 02/12/2020
 *      Author: Juliana
 */

#ifndef INCLUDES_OS_TASKS_H_
#define INCLUDES_OS_TASKS_H_



#include "fsl_device_registers.h"
#include "clockManl.h"
#include "pin_init.h"
#include "osal.h"
#include "free_rtos.h"
#include "standby.h"
#include "running.h"




#define SM_LED_DELAY (uint32_t) 2000

#define SM1_STATE_INIT (uint32_t)              0
#define SM1_STATE_VERMELHO (uint32_t)          1
#define SM1_STATE_WAITING_CINZA (uint32_t)     2
#define SM1_STATE_VERDE (uint32_t)             3
#define SM1_STATE_WAITING_PRETO (uint32_t)     4
#define SM1_STATE_AZUL (uint32_t)              5
#define SM1_STATE_WAITING_AMARELO (uint32_t)   6
#define SM1_STATE_RESET (uint32_t)             7

#define SM2_STATE_INIT (uint32_t)               0
#define SM2_STATE_WAITING_VERMELHO (uint32_t)   1
#define SM2_STATE_CINZA (uint32_t)              2
#define SM2_STATE_WAITING_VERDE (uint32_t)      3
#define SM2_STATE_PRETO (uint32_t)              4
#define SM2_STATE_WAITING_AZUL (uint32_t)       5
#define SM2_STATE_AMARELO (uint32_t)            6
#define SM2_STATE_RESET (uint32_t)              7

#ifdef _cplusplus
extern "C"
#endif

/* INCLUDES_OS_TASK_H_
 *
 */

void  SM1(uint32_t current_state);
