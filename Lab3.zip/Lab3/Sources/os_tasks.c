/*
 * os_tasks.c
 *
 *  Created on: 30/11/2020
 *      Author: Juliana
 */


#include "Cpu.h"
#include "Events.h"
#include "os_tasks.h"
#include  "ledrgb_hal.h"

#ifdef _cplusplus
extern "C" {
#endif

void clearAllLed(voi) {

	ledrgb_clearBlueLed();
	ledrgb_clearGreenLed();
	ledrgb_clearRedLed();

}



void SM1(uint32_t current_state) {

switch (current_state){

 case SM1_STATE_INIT:
 ledrgb_init();
 break;

 case SM1_STATE_VERMELHO:
 clearAllLed();
 ledrgb_setRedLed();
 break;

 case SM1_STATE_VERDE:
 clearAllLed();
 ledrgb_setGreenLed();
 break;

 case SM1_STATE_AZUL:
 clearAllLed();
 ledrgb_setBlueLed();
 break;

 case SM1_STATE_RESET:
 clearAllLed();
 break;

 case SM1_STATE_WAITING_AMARELO:
 break;

 case SM1_STATE_WAITING_PRETO:
 break;

case SM1_STATE_WAITING_CINZA:
 break;
     }


 void SM2(uint32_t current_state) {

 switch (current_state){

 case SM2_STATE_INIT:
 ledrgb_init();
 break;

 case SM2_STATE_CINZA:
 clearAllLed();
 ledrgb_setRedLed();
 ledrgb_setBlueLed();
 break;

 case SM2_STATE_PRETO:
 clearAllLed();
 ledrgb_setBlueLed();
 ledrgb_setGreenLed();
 break;

 case SM2_STATE_AMARELO:
 clearAllLed();
 ledrgb_setGreenLed();
 ledrgb_setRedLed();
 break;

 case SM2_STATE_RESET:
 clearAllLed();
 break;

 case SM2_STATE_WAITING_AZUL:
 break;

case SM2_STATE_WAITING_VERDE:
 break;

 case SM2_STATE_WAITING_VERMELHO:
 break;

 }

 }

 /*
** ===================================================================
** RTOS task routine. The routine is generated into task.c
** task_init_data - Parameter to be passed to the
** task when it is created.
*/
/* ===================================================================*/
void Task1_task(task_param_t task_init_data)
 {
      /* Write your local variable definition here */
           uint32_t SM1_CURRENT_STATE=0;

#ifdef PEX_USE_RTOS

   while (1) {
#endif


	   SM1(SM1_CURRENT_STATE);
   OSA_TimeDelay(SM_LED_DELAY);

if (SM1_CURRENT_STATE == SM1_STATE_RESET) {
  SM1_CURRENT_STATE = SM1_STATE_INIT;
  } else {
    SM1_CURRENT_STATE += 1;
  }

#ifdef PEX_USE_RTOS
  }
#endif
  }

 /*
 ** ===================================================================
 ** Event : Task2_task (module os_tasks)
 **
 ** Component : running [task]
 */
 /* ===================================================================*/


 void Task2_task(task_param_t task_init_data)
 {
 /* Write your local variable definition here */
     uint32_t SM2_CURRENT_STATE=0;

   #ifdef PEX_USE_RTOS

   while (1) {
 #endif

	    SM2(SM2_CURRENT_STATE);
 // inicia a M�quina 2
 OSA_TimeDelay(SM_LED_DELAY);

 if (SM2_CURRENT_STATE == SM2_STATE_RESET) {
  SM2_CURRENT_STATE = SM2_STATE_INIT;
  } else {
  SM2_CURRENT_STATE += 1;
  }
 #ifdef PEX_USE_RTOS
  }
  #endif }
/*
 *
 *END task */





